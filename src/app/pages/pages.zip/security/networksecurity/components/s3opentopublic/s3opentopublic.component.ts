import { Component } from '@angular/core';

@Component({
  selector: 's3opentopublic',
  templateUrl: './s3opentopublic.html',
  styleUrls: ['./s3opentopublic.scss']
})

export class S3OPENTOPUBLIC {
}
