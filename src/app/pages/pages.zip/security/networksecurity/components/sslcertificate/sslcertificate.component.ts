import { Component } from '@angular/core';

@Component({
  selector: 'sslcertificate',
  templateUrl: './sslcertificate.html',
  styleUrls: ['./sslcertificate.scss']
})

export class SSLCERTIFICATE {
}
