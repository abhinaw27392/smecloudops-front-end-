import {Component} from '@angular/core';

@Component({
  selector: 'generalsecurity',
  template: `<router-outlet></router-outlet>`
})
export class GeneralSecurity {
  constructor() {
  }
}
