import {Component} from '@angular/core';

@Component({
  selector: 'dbsecurity',
  template: `<router-outlet></router-outlet>`
})
export class DbSecurity {
  constructor() {
  }
}
