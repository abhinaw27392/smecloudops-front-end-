import {Component} from '@angular/core';

@Component({
  selector: 'security',
  template: `<router-outlet></router-outlet>`
})
export class Security {
  constructor() {
  }
}
