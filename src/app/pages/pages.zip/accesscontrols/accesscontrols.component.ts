import {Component} from '@angular/core';

@Component({
  selector: 'accesscontrols',
  template: `<router-outlet></router-outlet>`
})
export class AccessControls {
  constructor() {
  }
}
