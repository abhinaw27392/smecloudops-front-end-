import {Component} from '@angular/core';

@Component({
  selector: 'assetmanagement',
  template: `<router-outlet></router-outlet>`
})
export class AssetManagement {
  constructor() {
  }
}
